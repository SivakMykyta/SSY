#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>   // P?id�no pro uint8_t, uint16_t, size_t
#include <stddef.h>   // pro size_t
#include "spi.h"
#include "w5500.h"
#include "ssd1306.h" // Knihovna pro OLED displej

int main(void)
{
	// Inicializace SPI pro W5500
	SPI_init();
	DDRD |= (1 << PD7);     // Nastaven� Chip Select pin pro W5500 jako v�stup
	PORTD |= (1 << PD7);    // Nastaven� Chip Select na HIGH (neaktivn�)

	// Kr�tk� pauza pro stabilizaci W5500
	_delay_ms(200);

	// Inicializace OLED displeje
	ssd1306_init();        // Inicializace OLED
	ssd1306_clear();       // Vymaz�n� displeje
	ssd1306_draw_string(0, 0, "Start W5500", 1); // Zobrazen� textu na OLED
	ssd1306_display();     // Aktualizace displeje

	// Test W5500 komunikace
	uint8_t version = w5500_read(0x0039, 0x00);  // ?ten� verze z W5500

	// Zobrazen� v�sledku na OLED
	if (version == 0x04) {
		ssd1306_clear();
		ssd1306_draw_string(0, 0, "W5500 OK", 1);  // Zobraz� OK, pokud je verze spr�vn�
		ssd1306_display();
		} else {
		ssd1306_clear();
		ssd1306_draw_string(0, 0, "W5500 FAIL", 1); // Zobraz� FAIL, pokud je probl�m s W5500
		ssd1306_display();
		ssd1306_draw_string(0, 1, "Version: ", 1);  // Dopl?te pro lad?n�
		ssd1306_draw_string(0, 2, "0x", 1);         // Uk�zka jak zobrazit hodnotu
		ssd1306_display();
	}

	while (1) {
		// M?�ete p?idat dal�� logiku nebo funkce
		_delay_ms(1000); // T?eba 1s pauza
	}
}