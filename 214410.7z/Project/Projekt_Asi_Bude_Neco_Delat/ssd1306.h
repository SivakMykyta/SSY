#ifndef SSD1306_H
#define SSD1306_H

#include <stdint.h>   // pro uint8_t, uint16_t, ...
#include <stddef.h>   // pro size_t

// I2C adresa SSD1306
#define SSD1306_ADDR 0x78

// Funkce pro inicializaci a ovl�d�n� displeje
void ssd1306_init(void);
void ssd1306_clear(void);
void ssd1306_display(void);
void ssd1306_draw_string(uint8_t x, uint8_t y, const char* str, uint8_t font_size);
void ssd1306_write_command(uint8_t cmd);
void ssd1306_write_data(uint8_t* data, size_t len);

#endif
