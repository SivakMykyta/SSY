#include <stdint.h>
#include <stddef.h>
#include "spi.h"
#include <avr/io.h>

#define W5500_CS_LOW()  (PORTD &= ~(1 << PD7))
#define W5500_CS_HIGH() (PORTD |= (1 << PD7))

uint8_t w5500_read(uint16_t addr, uint8_t block) {
	W5500_CS_LOW();

	SPI_transfer((addr & 0xFF00) >> 8);      // Adresa high byte
	SPI_transfer(addr & 0x00FF);             // Adresa low byte
	SPI_transfer((block << 3) | 0x00);       // Block + Read mode (0x00)

	uint8_t data = SPI_transfer(0x00);       // Dummy write, ?teme data

	W5500_CS_HIGH();
	return data;
}
