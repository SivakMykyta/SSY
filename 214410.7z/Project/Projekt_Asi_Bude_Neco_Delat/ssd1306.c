#include "ssd1306.h"
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <util/twi.h>
#include <stdint.h>   // pro uint8_t, uint16_t, ...
#include <stddef.h>   // pro size_t

#define F_CPU 8000000UL // Nastavte podle sv�ho taktov�n�

// I2C funkce pro odes�l�n� dat (pou��v� TWI na ATmega)
int hal_i2c_write(uint8_t addr, uint8_t* data, size_t len) {
	TWBR = 32; // Nastav�me TWI bitrate na 100kHz

	// Start podm�nky
	TWCR = (1 << TWSTA) | (1 << TWINT) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT))) { }

	// Odesl�n� adresy s WRITE (0x78 = adresa pro z�pis)
	TWDR = addr;
	TWCR = (1 << TWINT) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT))) { }

	// Odesl�n� dat
	for (size_t i = 0; i < len; i++) {
		TWDR = data[i];
		TWCR = (1 << TWINT) | (1 << TWEN);
		while (!(TWCR & (1 << TWINT))) { }
	}

	// Stop podm�nky
	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWSTO);
	while (TWCR & (1 << TWSTO)) { }

	return 0; // �sp?ch
}

// Funkce pro z�pis p?�kazu na SSD1306
void ssd1306_write_command(uint8_t cmd) {
	uint8_t data[1] = { cmd };
	hal_i2c_write(SSD1306_ADDR, data, 1);
}

// Funkce pro z�pis dat na SSD1306
void ssd1306_write_data(uint8_t* data, size_t len) {
	hal_i2c_write(SSD1306_ADDR + 1, data, len); // Adresa pro z�pis dat je o 1 vy���
}

// Inicializace SSD1306
void ssd1306_init(void) {
	ssd1306_write_command(0xAE); // Vypnut� displeje
	ssd1306_write_command(0xD5); // Nastaven� frekvence hodin
	ssd1306_write_command(0x80); // (frekvence je 0x80)
	ssd1306_write_command(0xA8); // Nastaven� multiplexn� pom?r
	ssd1306_write_command(0x3F); // Nastav�me maxim�ln� hodnotu multiplexu
	ssd1306_write_command(0xD3); // Nastaven� posunu
	ssd1306_write_command(0x00); // Nastaven� posunu na 0
	ssd1306_write_command(0x40); // Nastaven� za?�tku v�pisu z pam?ti
	ssd1306_write_command(0x8D); // Povol�me nap�jen� pro charge pumpu
	ssd1306_write_command(0x14); // Povol�me charge pumpu
	ssd1306_write_command(0xA1); // Nastaven� zrcadlen� obrazu
	ssd1306_write_command(0xC8); // Nastaven� zrcadlen� obrazu vertik�ln?
	ssd1306_write_command(0xDA); // Nastaven� po?tu ?�dk? v ka�d�m sloupci
	ssd1306_write_command(0x12); // Nastaven� po?tu ?�dk? na 1 (typick� pro OLED)
	ssd1306_write_command(0x81); // Nastaven� kontrastu
	ssd1306_write_command(0x7F); // Maxim�ln� kontrast
	ssd1306_write_command(0xA4); // Zapnut� norm�ln�ho re�imu
	ssd1306_write_command(0xA6); // Normaln� zobrazen� (ne invertovan�)
	ssd1306_write_command(0xAF); // Zapnut� displeje
}

// Vymaz�n� displeje (nastaven� na 0)
void ssd1306_clear(void) {
	uint8_t clear[128] = { 0 };
	for (int i = 0; i < 8; i++) {
		ssd1306_write_command(0xB0 + i);      // Nastaven� ?�dku
		ssd1306_write_command(0x00);           // Nastaven� sloupce za?�tek
		ssd1306_write_command(0x10);           // Nastaven� sloupce konec
		ssd1306_write_data(clear, sizeof(clear)); // Posl�n� dat pro vymaz�n�
	}
}

// Zobrazen� dat na displeji
void ssd1306_display(void) {
	// V tomto bod? lze p?idat funkce pro rozlo�en� nebo animace
}

// Vykreslen� textu na displeji (velikost p�sma 1x)
void ssd1306_draw_string(uint8_t x, uint8_t y, const char* str, uint8_t font_size) {
	while (*str) {
		// V�pis ka�d�ho znaku na OLED
		ssd1306_write_command(0x00); // Nastaven� za?�tku
		ssd1306_write_command(x); // Nastaven� X pozice
		ssd1306_write_command(y); // Nastaven� Y pozice
		ssd1306_write_data((uint8_t*)str, 1); // Vypi� znak
		str++;
	}
}
