#include "spi.h"
#include <stdint.h>   // pro uint8_t, uint16_t, ...
#include <stddef.h>   // pro size_t

// Inicializace SPI pro ATmega256RFR2
void SPI_init(void) {
	// Nastaven� SPI: MSTR = 1 (master), SPE = 1 (SPI povoleno), SPR0 = 0 (rychlost)
	SPCR = (1 << SPE) | (1 << MSTR);   // SPI povoleno, master re�im
	SPSR = 0;                          // Rychlost nastavena na standardn�
}

// P?enos jednoho byte p?es SPI
uint8_t SPI_transfer(uint8_t data) {
	SPDR = data;                   // Po�li data do SPI Data Register
	while (!(SPSR & (1 << SPIF)))   // ?ek�n�, dokud nebude p?enos dokon?en
	;
	return SPDR;                    // Vr�t� p?ijat� byte
}
