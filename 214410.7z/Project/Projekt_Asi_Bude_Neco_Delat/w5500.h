#ifndef W5500_H
#define W5500_H

#include <stdint.h>

uint8_t w5500_read(uint16_t addr, uint8_t block);

#endif // W5500_H
